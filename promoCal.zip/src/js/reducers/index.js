import { combineReducers } from "redux"
import event from "./eventReducer"

export default combineReducers({
  event,
})
